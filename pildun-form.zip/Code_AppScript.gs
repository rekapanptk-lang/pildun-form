// ============================================
// APPS SCRIPT - Database Handler
// Sheet ID : 1azmtlaBar2jMs_jmIEtpRhLruWYMgtdZgqftGcvWJyc
// Gmail    : rekapanptk@gmail.com
// ============================================

const SHEET_ID       = '1azmtlaBar2jMs_jmIEtpRhLruWYMgtdZgqftGcvWJyc';
const SHEET_RESPONSE = 'DB_Pildun';
const SHEET_AUTH     = 'DB_Auth';
const SHEET_CONFIG   = 'DB_Config';

function doGet(e) {
  const action = e.parameter.action || '';

  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  if (action === 'getConfig') return jsonOut(getConfig(), headers);
  if (action === 'save')      return jsonOut(saveData(e.parameter), headers);
  if (action === 'sendEvent') return jsonOut(sendEventHandler(e.parameter), headers);

  return jsonOut({ success: false, error: 'Unknown action' }, headers);
}

// ── GET CONFIG PERTANDINGAN AKTIF ──
function getConfig() {
  try {
    const sheet = SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_CONFIG);
    if (!sheet) return { success: true, data: [] };

    const data   = sheet.getDataRange().getValues();
    const result = [];

    for (let i = 1; i < data.length; i++) {
      const [aktif, pertandingan, timA, timB, tanggal, jam] = data[i];
      if (String(aktif).toUpperCase() === 'TRUE' && pertandingan) {
        result.push({ pertandingan, timA, timB, tanggal, jam });
      }
    }

    return { success: true, data: result };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

// ── SIMPAN DATA RESPONSE + TOKEN ──
function saveData(p) {
  try {
    const ss = SpreadsheetApp.openById(SHEET_ID);

    // Simpan jawaban form ke DB_Pildun
    const respSheet = ss.getSheetByName(SHEET_RESPONSE);
    const lastRow   = respSheet.getLastRow();
    respSheet.appendRow([
      lastRow,                  // No
      new Date(),               // Timestamp
      p.nama         || '',     // Nama
      p.email        || '',     // Email
      p.noHp         || '',     // No HP
      p.pertandingan || '',     // Pertandingan
      p.timA         || '',     // Tim A
      p.timB         || '',     // Tim B
      p.skorA        || '0',    // Skor A
      p.skorB        || '0'     // Skor B
    ]);

    // Simpan token ke DB_Auth
    const authSheet = ss.getSheetByName(SHEET_AUTH);
    const authData  = authSheet.getDataRange().getValues();
    let updated     = false;

    for (let i = 1; i < authData.length; i++) {
      if (authData[i][0] === p.email) {
        authSheet.getRange(i + 1, 1, 1, 6).setValues([[
          p.email,
          p.nama,
          p.accessToken,
          p.refreshToken || authData[i][3] || '',
          'authorized',
          new Date()
        ]]);
        updated = true;
        break;
      }
    }

    if (!updated) {
      authSheet.appendRow([
        p.email,
        p.nama,
        p.accessToken,
        p.refreshToken || '',
        'authorized',
        new Date()
      ]);
    }

    return { success: true };
  } catch(e) {
    Logger.log('saveData error: ' + e.toString());
    return { success: false, error: e.toString() };
  }
}

// ── SEND CALENDAR EVENT (dipanggil dari admin panel) ──
function sendEventHandler(p) {
  const title    = p.title    || 'Event';
  const start    = p.start    || '';
  const end      = p.end      || '';
  const desc     = p.desc     || '';
  const mode     = p.mode     || 'all';
  const specific = p.specific || '';

  if (!start || !end) return { success: false, error: 'Waktu kosong' };

  const sheet = SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_AUTH);
  const data  = sheet.getDataRange().getValues();
  let sent = 0, failed = 0;

  for (let i = 1; i < data.length; i++) {
    const [email, , accessToken, refreshToken, status] = data[i];
    if (!email || status !== 'authorized') continue;
    if (mode === 'one' && email !== specific) continue;

    let token = accessToken;
    if (refreshToken) {
      const refreshed = refreshAccessToken(refreshToken);
      if (refreshed) {
        token = refreshed;
        sheet.getRange(i + 1, 3).setValue(token);
      }
    }

    createCalendarEvent(token, title, start, end, desc) ? sent++ : failed++;
  }

  return { success: true, sent, failed };
}

// ── REFRESH TOKEN ──
function refreshAccessToken(refreshToken) {
  try {
    const CLIENT_ID     = '69593145654-5c2n90v8f3cetmtjl91u7ua00rg7rub2.apps.googleusercontent.com';
    const CLIENT_SECRET = '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';
    const resp = UrlFetchApp.fetch('https://oauth2.googleapis.com/token', {
      method: 'post',
      payload: { client_id: CLIENT_ID, client_secret: CLIENT_SECRET, refresh_token: refreshToken, grant_type: 'refresh_token' },
      muteHttpExceptions: true
    });
    const r = JSON.parse(resp.getContentText());
    return r.access_token || null;
  } catch(e) { return null; }
}

// ── CREATE CALENDAR EVENT ──
function createCalendarEvent(accessToken, title, startStr, endStr, desc) {
  try {
    const event = {
      summary:     title,
      description: desc,
      start: { dateTime: new Date(startStr).toISOString(), timeZone: 'Asia/Jakarta' },
      end:   { dateTime: new Date(endStr).toISOString(),   timeZone: 'Asia/Jakarta' },
      reminders: {
        useDefault: false,
        overrides:  [{ method: 'popup', minutes: 60 }, { method: 'popup', minutes: 15 }]
      }
    };
    const resp = UrlFetchApp.fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
      method: 'post',
      headers: { 'Authorization': 'Bearer ' + accessToken, 'Content-Type': 'application/json' },
      payload: JSON.stringify(event),
      muteHttpExceptions: true
    });
    return !!JSON.parse(resp.getContentText()).id;
  } catch(e) { return false; }
}

// ── SETUP SHEETS ──
function setupSheets() {
  const ss = SpreadsheetApp.openById(SHEET_ID);

  if (!ss.getSheetByName(SHEET_RESPONSE)) {
    const s = ss.insertSheet(SHEET_RESPONSE);
    s.appendRow(['No', 'Timestamp', 'Nama', 'Email', 'No HP', 'Pertandingan', 'Tim A', 'Tim B', 'Skor A', 'Skor B']);
    s.getRange(1,1,1,10).setFontWeight('bold').setBackground('#1a1a2e').setFontColor('white');
  }

  if (!ss.getSheetByName(SHEET_AUTH)) {
    const s = ss.insertSheet(SHEET_AUTH);
    s.appendRow(['Email', 'Nama', 'Access Token', 'Refresh Token', 'Status', 'Timestamp']);
    s.getRange(1,1,1,6).setFontWeight('bold').setBackground('#1a1a2e').setFontColor('white');
  }

  if (!ss.getSheetByName(SHEET_CONFIG)) {
    const s = ss.insertSheet(SHEET_CONFIG);
    s.appendRow(['Aktif', 'Pertandingan', 'Tim A', 'Tim B', 'Tanggal', 'Jam']);
    s.getRange(1,1,1,6).setFontWeight('bold').setBackground('#1a1a2e').setFontColor('white');
    s.appendRow(['TRUE',  'KOREA SELATAN VS REPUBLIK CEKO', 'Korea Selatan', 'Republik Ceko', '2026-06-10', '19:00']);
    s.appendRow(['FALSE', 'BRASIL VS ARGENTINA',            'Brasil',        'Argentina',     '2026-06-11', '20:00']);
  }
}

function jsonOut(obj, headers) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
